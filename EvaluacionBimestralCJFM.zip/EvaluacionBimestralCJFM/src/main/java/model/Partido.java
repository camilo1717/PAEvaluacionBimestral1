package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;

public class Partido implements Callable<Integer> {
    private final int jugador1;
    private final int jugador2;
    private final Random aleatorio = new Random();

    public Partido(int jugador1, int jugador2) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
    }

    @Override
    public Integer call() throws Exception {
        List<Integer> setsGanados = new ArrayList<>();
        int setsJugador1 = 0;
        int setsJugador2 = 0;

        for (int i = 1; i <= 3; i++) {
            int ganadorSet = aleatorio.nextBoolean() ? jugador1 : jugador2;
            setsGanados.add(ganadorSet);

            if (ganadorSet == jugador1) setsJugador1++;
            else setsJugador2++;

            if (setsJugador1 == 2 || setsJugador2 == 2) break;
        }

        // Simula duración del partido entre 1.5 y 2 segundos
        Thread.sleep(1500 + aleatorio.nextInt(501));

        synchronized(System.out) {
            System.out.println("Jugador " + jugador1 + " vs Jugador " + jugador2);
            for (int i = 0; i < setsGanados.size(); i++) {
                System.out.println("Set " + (i+1) + ": Jugador " + setsGanados.get(i));
            }
            int ganador = (setsJugador1 > setsJugador2) ? jugador1 : jugador2;
            System.out.println("Ganador del partido: Jugador " + ganador + "\n");
        }

        return (setsJugador1 > setsJugador2) ? jugador1 : jugador2;
    }
}

