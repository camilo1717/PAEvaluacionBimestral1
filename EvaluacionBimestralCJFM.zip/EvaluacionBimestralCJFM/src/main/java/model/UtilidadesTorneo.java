package model;

public class UtilidadesTorneo {
    public static String obtenerNombreRonda(int cantidadJugadores) {

        return switch (cantidadJugadores) {
            case 16 -> "OCTAVOS DE FINAL";
            case 8  -> "CUARTOS DE FINAL";
            case 4  -> "SEMIFINAL";
            case 2  -> "FINAL";
            default -> "RONDA";
        };
    }
}


