package ec.edu.utpl.carreras.computacion.proava.clases.s1;

import model.Partido;
import model.UtilidadesTorneo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class TorneoTenis {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        System.out.println("----- TORNEO DE TENIS -----");
        List<Integer> jugadores = new ArrayList<>();
        for (int i = 1; i <= 16; i++) {
            jugadores.add(i);
        }

        ExecutorService ejecutor = Executors.newFixedThreadPool(8);

        while (jugadores.size() > 1) {
            String nombreRonda = UtilidadesTorneo.obtenerNombreRonda(jugadores.size());
            System.out.println("===== " + nombreRonda + " =====");

            List<Future<Integer>> resultados = new ArrayList<>();
            for (int i = 0; i < jugadores.size(); i += 2) {
                int jugador1 = jugadores.get(i);
                int jugador2 = jugadores.get(i + 1);
                Partido partido = new Partido(jugador1, jugador2);
                resultados.add(ejecutor.submit(partido));
            }

            List<Integer> ganadores = new ArrayList<>();
            for (Future<Integer> resultado : resultados) {
                ganadores.add(resultado.get());
            }
            jugadores = ganadores;
        }

        System.out.println("¡Campeón del torneo: Jugador " + jugadores.get(0) + "!");
        ejecutor.shutdown();
    }
}

